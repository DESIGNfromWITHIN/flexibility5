<?php
header('Content-type: text/cache-manifest');
?>CACHE MANIFEST
# 2011-09-22:v8

# Explicitly cached 'master entries'.
CACHE:
templates/default/images/restyle/headers.jpg
templates/default/images/modx-theme/panel/tool-sprites.gif
templates/default/images/style/modx-logo-header.png

templates/default/images/restyle/contentArea_bg.png
templates/default/images/restyle/headers.jpg
templates/default/images/style/modx-logo-header.png
templates/default/images/style/separator/menu_sep.png
templates/default/images/modx-theme/qtip/tip-anchor-sprite.gif
templates/default/images/restyle/icons/arrow_down.png
templates/default/images/restyle/icons/arrow_up.png
templates/default/images/restyle/icons/refresh.png
templates/default/images/restyle/icons/template.png
templates/default/images/restyle/icons/tv.png
templates/default/images/restyle/icons/chunk.png
templates/default/images/restyle/icons/snippet.png
templates/default/images/restyle/icons/plugin.png
templates/default/images/modx-theme/dd/drop-no.gif
templates/default/images/modx-theme/layout/mini-left.gif
assets/ext3/resources/images/default/s.gif
templates/default/images/modx-theme/tree/leaf.gif
templates/default/images/modx-theme/tree/arrows.gif
templates/default/images/modx-theme/tree/folder.gif
templates/default/images/modx-theme/grid/loading.gif
templates/default/images/restyle/icons/context.png

NETWORK:
*