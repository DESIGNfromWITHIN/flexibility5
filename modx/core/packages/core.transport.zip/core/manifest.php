<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b4b4abb22cb78449602e451cc65f2096',
      'native_key' => 'core',
      'filename' => 'modNamespace/05111db99643790b761c4088a6abc648.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '43c6b3c73ad133f452a34ba7696ddc43',
      'native_key' => 1,
      'filename' => 'modWorkspace/084ec7b34f73db6d3aafaf3bdea3e4d3.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '4cf5e22a122b3e38cb629c30f7682f85',
      'native_key' => 1,
      'filename' => 'modTransportProvider/672142065d9883835500e8f1b682d81b.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '651a12186d13c2558b5225c1b270f2b5',
      'native_key' => 'topnav',
      'filename' => 'modMenu/99c996b8fb7d7025dfcbd38af4add176.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '542bf4db686b3a9edf02528cbe877ab8',
      'native_key' => 'usernav',
      'filename' => 'modMenu/2e34437f6018c4ab50449c79bd403c0d.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fa3c5df9bd1d23657adaee8e3a17787a',
      'native_key' => 1,
      'filename' => 'modContentType/97305524d3a674f9d2566449bdc2d255.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '8a1b67121ab14ca96b533d8866aba321',
      'native_key' => 2,
      'filename' => 'modContentType/a75be22b222e00cbba53a98291e5e51c.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0f71ffe65777ba4be793d01a24748087',
      'native_key' => 3,
      'filename' => 'modContentType/02f2d14bf3e758d635beceb1ada26ccd.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '710fc541d8c84833e7631f518b511764',
      'native_key' => 4,
      'filename' => 'modContentType/83ca2e1eb6c7aa51ebb51ab8930f8563.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0461614859ffb86ed5865fffab481e6e',
      'native_key' => 5,
      'filename' => 'modContentType/72f9fc4659ec238b407c876007554e7e.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2869193cb26076e15f3da43923c692dd',
      'native_key' => 6,
      'filename' => 'modContentType/86baa7b3ae6f3c63bb343bed02937fac.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b6cc1d349cff7d1d2e4ea9d4225a1340',
      'native_key' => 7,
      'filename' => 'modContentType/46f1e9610656275aca84c1e6cb6d17c5.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'dce9c2033dd05859e252f3f270254e85',
      'native_key' => 8,
      'filename' => 'modContentType/1eecbf0868262930960e6d5d69fc66c5.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f525741deaf8b80ee0b102efce5ad4de',
      'native_key' => NULL,
      'filename' => 'modClassMap/4bf99f520902cd277d5d786673df7496.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2b5fbdadd08c2369f12c4fd85c39e44d',
      'native_key' => NULL,
      'filename' => 'modClassMap/3b158ad1e11fe2f2f01f77300c6dd705.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1cb4aacddce3912ab1805c83bcd49566',
      'native_key' => NULL,
      'filename' => 'modClassMap/e5578e95bb60e837929be51f86c15987.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c83b5b184aec62ca724e2dc3fe2a2688',
      'native_key' => NULL,
      'filename' => 'modClassMap/8e93997177ede6889cf4c922b5406656.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4d75bcb7747c1c51796a763f24d40736',
      'native_key' => NULL,
      'filename' => 'modClassMap/a21af56d86b48c12a629db0795f69e96.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cc2a9ac70aba92eaed8a031059edf4c6',
      'native_key' => NULL,
      'filename' => 'modClassMap/e79356a5a0a507adb2275ddb106e0dc6.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b63c85694d26ae840d0e4aa2d71acd06',
      'native_key' => NULL,
      'filename' => 'modClassMap/0b60def340a7555a0a6b967734fd3cba.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1a5984d3fb8c9230582121d98a43ad1d',
      'native_key' => NULL,
      'filename' => 'modClassMap/fd2ef5bd4383a22667e52a67c0cef4d1.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3e033ceb94078646293209f7e58668de',
      'native_key' => NULL,
      'filename' => 'modClassMap/c0b8b4e26dbb23f73ba41ceba7f31285.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b68360284ca4e2a242db45f917db36a',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/b3988a60fd1ab8ff224d306a73331dc1.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3de5c3fe2af14d52f3acb921de1cd9e',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/46028a7b34b0de7f43b82811ce0a2f15.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f458971f0eb41a5d6ec49ddcb4c9a00c',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/eb22648e788df2f5be5b20ee4206d9db.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44da57aed0ae37bc0ad5e3940f857e4d',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/e915c75f5aa5ed5682bf6f4f687859b5.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df53d0d0bdc7db36807b2340cb40d3dc',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/14ae4b85ec4c458c09479fc4b4241aa7.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41997920c23d0d6e07c05922257b1880',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/c39490d3f252f65310a00057912c019f.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c9a05964a98655d18505ac081b3840e',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/f00b27db97f907443e4fb55797ae0797.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '331d3be880def4be9d7d75535c5df317',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/7c51ca566ba37dfe109afcedb170ab1d.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0642b593b8422afe36663e2258e1a615',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/ed518831a186722df9b50a959acf04b7.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f449ffdebc6f4f5fbd6cf05bf2b934d',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/331f63bb74ae4d63ae3d21acc9a85497.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a5cf7560817c14bbea417f1e120d212',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/fba2fb61979ae3b85e70cff61f355e67.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de7d20041cb5524c6445635a98aeb372',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/59fa1149b7430a1e22bbcb1becf7a15d.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84cdf7077a279a2aa21d3fab5e21ba8f',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/7139b2515d601b3dfa1416c5e29b0553.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb02a7e53bb11324f4122cbca2148be4',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/11a06528ec989f31f0184c96c47770eb.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c904f644d21cbe86603ea2b04c84661',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/1f024a555b908c676878b40114387e43.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '614a29033c3d2e1b4c7b79be49876a91',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/97bb88f90329d3dfe680b6b9b7fa217f.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9592af6253be713975573f9f7345469',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/f1623dc0cf4ce58605c796e140f071cf.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '019db7943944edba9fa720b9a54b9b93',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/cead649cee2ccc461bd2380c1acf9fc8.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cd37b650bb69e4b247695c8e03ee63a',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/1af53da9519f5b36f6e6217ab69926df.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59703723bb275e710857901ac99c25f3',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/4b60bf958f21b06aef9ad43da76374d2.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd632441619dbc3efa59c16addb3874a',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/7de9424b00f4ce03ab4f8f00b45d0303.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa2ba0f9d275a87544a55ddb9986433e',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/8ddf4e6a3c9535b55328f58b0af0ab34.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c654f62352be51d2b158fd5a54eb348',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/f74eaa5c6d3ea5825063ac0626e8f454.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdf1b1e1f979b64173ecc05c16af8bee',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/3ad41247f2ddaa8036e9b80b38053735.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '800e3c4364fa3227419668e67f93cb92',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/5c05a98ebc17eeadf57ca9def172828a.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3db59565efc4e110f72cd243dde691ab',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/5a2d818fa4466f568250b4da7caa4f03.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7a4b2665037fa60ed6dad6c1cdb2d6d',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/68411effd58cfe0b29c5b3894360cd4e.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2461dcb9d368244694888b72d1ca397',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/54aaf757e5b62246bb79444bd462f637.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a11110da516d81b9d2ef158346edacf',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/d964721f9e2092cfff0c74dc3bb3c872.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f5d66365f7f4ac73bbb60fb1d88bb43',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/7d4a71faf2eceee70f851385d0dd3562.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e5bdffe38680730280ea69a8c5440c3',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/475fc554f44df1f24a977d024ae788d7.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13b02876bacc07e7c1f6c8037a0cc8f1',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/1885b48df2a39ccd01f2d4a31921cf2e.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbc1a185c69feb58cd483667da8b97c6',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/01cecb669a351cb2a0358e12818052ba.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9d0d891a859118bf446265160496760',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/d91a149bdbc584435e5e2b27f67b36c8.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '665c12788df11c59e82c0d5186dc3a41',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/fca907457fc68f4bd3ead3a56f94c4e8.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11e3b3467541d44290b435eb30a7a304',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/5cda9c9ff1ed5fbce359e8d2ca671ad9.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d8188f8cb34c59852795bed07aec3c9',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/f2caebb7ccf80020fd8a850efcf4645f.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc3f7f7508f6aadd4b278358a18a7ab2',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/251200278f2bd3d15040be318e0abf8d.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b120d750d5ac96257bf1018c36d7417',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/779db727c7258cf2c43f6efc48ee5c33.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff4fb7a6d6deabec8a7e97c8e92e71d2',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/810ffa1fbda6a099535652a5b89383d9.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a65438528deb7b1b0f5e5c68812583f1',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/5adf27cf6837ab1237d235f5de7ba2b5.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11d880b40aa38ee4bbb9dd903312d301',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/c3fdef999e94b8b4edc151cf3db157cc.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b317c388b41e173dedde93368a1e06e',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/6aeb6ae3f0d9585707ed00e6e4212065.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '723da29fb48b0adabe305df9218d1cf4',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/27740c0eb37d3060a14cedc19b45df67.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78cdc1090c3edbf0ef18f2d606134f96',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/5e64e0006bcfaebc1cfe203b870ea3d2.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8aaaf5c36019906c50db44268444b860',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/8ca79d1aac21bcecdfd439252284e2a5.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42386c3f77741602133da370d93546a2',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/c4394b251f36c980c72e21caf36712e8.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b86216e8132cb6bfe0ba675c26060346',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/9d05f9a40c9302182fda480299416fc0.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76d7a236220a28bd5ed2287c762c4ab2',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/4956d21d8c7346df903fc2e30c4e1d33.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5378073a645e055ae0205a9985a26232',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/549808aae14e03774beebfca67eecbe0.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efd41669c5efed4d011b9917adafd96c',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/074103e6946493aae6f02e41dec2637e.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3281a99c8feb6cdc8ba041f6a7f8820',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/265c0b4edb9becb5ac9dfda1ca89a0a3.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67d98868723fbed9362009ab525b4b6a',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/8e97642b7a01e43716acea9c208e12eb.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd294146bfdcc0353ab9f3a13bcb8dffc',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/ed5a97cae254b9565cb102252a642be9.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8231720b520c446fdad3e6b1a5ee4f7',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/c7544ba53da0e5e41e5265d0f11da996.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '575f24f9b0ed8ab0332ffae7e0d65ec8',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/c8c0f1c688bcf0eaaa3016a4ea7d6bb7.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32ca4171ea95cceee804679978dcb525',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/af31d29bb2a2d9023fbfdbc8e1595f27.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2743751226969f593b140015f0fcbed0',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/f2ce5c39918f0e95c9d248fc446f394f.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ac60ffb2108eb68b7c22b7433cb51df',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/b017799b40afb6a6a59439cd1c777175.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff60d2ecf8a873eb4416228290977a37',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/f22f304e84afb9f96cafd7f93001c97d.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb4b0f4d647a98973e88f91281043011',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/77ea70ab6f976b781b27ee29956016a4.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '719bc436ef64a5311146faf3dee80c96',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/4ed4a2b43f8dfebdabe7504a1283601d.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd32376de041ad81f9e7a4c6fd9004848',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/e61afdcfb763593f7cf4651bf1e7c38a.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28efdf971682de8429da710401d3d59d',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/83b1b5d04b573732841b0a29e8c94912.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1662b76d6201fc1e0291c9f889486e48',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/66dea6a78d33e86ff7c5a6167923bbf6.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e1f2237335e121320e7fe2bf9c9643b',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/ee41f28302fb2939dfaecbab58ba029c.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af591227811ca390d1f0ca074ae68ca4',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/58f4c9e42a882cfb562b5bc7e9292af2.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae368de3a1102f1bebf044899c557db1',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/d7288c481243b0c601285f56b11a1a76.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd72d1969c100ae19e27828e5272fe446',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/7aa4fad9499636300b038aeb8cf4fde9.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5104d3680e13ffb71bbb0577f5733121',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/4a3d7f158dfc0ec26c9b3d6a17c5163b.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb896a396d4e6be621005059055f2074',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/75d80059ad6f19d8cff065ad06c49465.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a879cd550df9cf38f3bb321b95cdb5a',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/31112595691f17e2617cad76060a9ea3.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '054d27d30bc0b95a0066787fd72f2b38',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/1dfecf5df8177a0c76d651b5086d4764.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '847a4c8213cfd292c9fd661357a47a88',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/6d0ad5737db6736b8ee466591917c13d.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0e59774ba652fe116b0b636b455e2e0',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/20a3dab45a8c67ce176f83f05987f0d3.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13c7646375dc9277ba0d2608c34b7183',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/a7f77a6d273a6aa3ea6119f97ae45455.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef86874f29d81729c13f9125db2a7f17',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/419d64dda22250acb7860fbc0c7dfdae.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a467a0ea0a48d67c7a3e66b08f848a5',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/4ccfe94f349ab6e667cf72356a7f8e89.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c8822714007e68a5a454e38018f2b20',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/948296ad3b8d0e2a8706a3fd3bfb2fa2.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be2987d703ce2ad2a87db3d889aefa21',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/7e2a85b9735f274aebcaf585ee1d815f.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8e36e8b28db2da51ddee19b85a5d580',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/23217e91884e8f3052a8094a7064ddb7.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '184f7d721668b03587af46bfb4d1bd8e',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/78e4b045fa16793a8960697c23050f33.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b1f0b26d9cad8cc1309fcde0e8d0ee3',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/73bb213448d93820b9d03d5d609cc52c.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06212b570f83970137d12c27b207bcf7',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/6cf524293a588017b9dfc11b2b51d09e.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59be41d2050c8740baf7fe69923e0599',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/34143ec786d435c6dd310c972e88333e.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcbb4a5b8a26ed09d5e60fb8c31c971f',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/908eb68aab529377b40823e9bc1cc892.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43c7df1e307f5c5cf3de338b64f6555c',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/ddf0584dfb2fa9c62522a5d9294fed07.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9d318c293fd8c5bf9e4223857ea65be',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/f80841515b3e7230fe295d2911024148.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b133d8a654c4c2b94fa62422e311d1ee',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/ef89e9517ad6fe1501f99ccf853db01c.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3f4db6dd3e66de7c8dc19b56a33634a',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/90adc9e66eb51fc9b969084710c6c3ab.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '002b02ec063f7e6d19a1acc840088fc4',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/32beb14cf3a18ecb0e1f0e6b74fc44eb.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e51d872dccb984980b71da01d26f3a1',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/01c6b56dd154c46037571f3e6dd8d774.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bff414d5ff45ee396e863d43fd8e7c56',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/342d2180c7d228ae337d6c1b5b48ddf4.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00456569dbae7fc636926d9c166308e3',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/eb1db53f80c24c68f2c332ddf45cb262.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80da41ecb11ccfd6d705dc02643a65b3',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/f2081642dfe8c09d7aad09d79db92e5c.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42fd1e85202c01a8722194f8db98a0db',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/59061a1a0020c9ed3ef648d8313b309a.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8dd47a357f4280484d833aecedc6cad3',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/c2743f1ef54f1d3e0fa915684b2975ef.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a7cd770d15b5c62c52737870b217ffe9',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/891d46ff2912cd699e6e1d716c699092.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5591090ff50a231fbb24f2e30e176b4d',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/c35e34ed5f406d2a537f73750b3fb837.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5540c5cd1c8a19b1dc72bc108db72dd6',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/33d142664ab23a2cd9d2e503c79a3f4e.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9eeb19dfc54dc928d6cb88fa9d32313e',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/dd3a26f0d670318493af03fcb8bf9646.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b41114ecc714a3faabe7e807d80f5df',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/385e6cbf18960fb5e83b605451dc81fe.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6bf20f48c857b7ba9fb89a166c69bbc',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/3412075d7bcc33b0e29601f1f5dd4599.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '809e4f39d532ad4d54aa171bb5cf023c',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/e058903284a899b25e731ce6397ee326.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0321604f12a05b3f4883fabfeeb3e0da',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/a1e3aeb814ffbf9b1b5dbd618fc40a25.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4ff358a7c6ec30f4e82b3d2ac9f38ce',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/fedb64759e6b352ec0dc239f055e7a8d.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36b43348f733829e0491a1f876963468',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/f943132dec6239a5acffb7a24587a0d9.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '519fd0edfb9789a733a2f0b23a45207d',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/caf60208b40882195b5e1fbd1172bafd.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9f42e9fc4a4067034459492ed9fdc0b',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/f8b35433f7eb52281791e9162189a97b.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a225daf8fe64cd5e23ede2319c85bc6',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/a9687aa7250f49ff94a4c07578de4e24.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccb441d316a4e628e37728d7e93bc8e2',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/6f46203c6937d85bdf63b6acf43290f3.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '880a3df2f0899f946d1ef2f94723151c',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/2ce233f7febb4848b63dad033c693e1d.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21fd66e6fadfd9124a40d3dee6649815',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/cc25d92546603590f8ac52b349f1c1e1.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '526a7ace965a928d6c28af62cf73d3d2',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/05afc5a13f77d65de6689f67a2bdc7fb.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a8b01162809e33048f9b19210913215',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/3c9bec7099cfc7cb7dd2faa11eb12583.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '312c0d214971c41b15a04891786fe4e6',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/0903a87c9059340cb9f3fdfb53c4fcda.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7e2f25c81e25852f76e06573aa339f1',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/dc5f2718c2e475b41cc9b594989ed9ea.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08797adde6fd2e322f156784ac1a5f43',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/64d71b1442e87b26e6356e95024e3724.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a4de73f1f76a6ed631511828bdeded3',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/9a334cbc3e750e325cef9062884c3dc4.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35e00e1277e604c258b53115482da7b5',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/ca10d5c0cafa90fcbfadedecb40edf73.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a41654b3eae7f7f2a75610fa7916a9fc',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/d91349af9b2a5e6a24bafc543eeb045f.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f32f339eeab51e9f8646fedd5aa3c0f',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/bf30eb395ee1fe47a43065126f37025f.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0787fee6557cbb73f9e0edcb0dbf108d',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/e22ec9f282d8a9a03bf204dcc04f2f52.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f9d4e7118e9bdff51b6a31064781325',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/629c1fc16b8bc3c12a1402f727f9585a.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bd8c56cbe960bfb76b43946fa0016f2',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/1bc2cdbed74222a0542835cd17ce456e.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7018b3dc9d2db769ba4a1c44b5914191',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/4b9782a6d3319db9d0c43fa0bf62b912.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3224ccac62911b19a024b3d6c5e8818',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/41429024e0369acbed6967cf7617f77b.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db08eb4dfa308a1f3843696bbc80a16a',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/c442eb633693e7ab181f40c1748083eb.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3af96ed8a8546a9036f9b63e7fba3ea',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/6c97e48e5d4fdbcfdec80e3f23cfbc6b.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34377fb68f820c173888ce2eb5372d56',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/6359d589948096b50fab17eb41172880.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d671eef9471280c54de2f6d47f5d07c',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/4f5bafde361227a13d460d7f6988c0d4.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c352f5e85b097fd8c8d75d974d58d4d7',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/d8e8887f0f4c2d481d94e36cbc301a2d.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2ee1b1a24dde2f11da3f59f46ae74ab',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/de34385c98fdc02c40aab943c74f93f8.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f9c8a83cc31495f151dab1526c4bf6d',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/45844c29fe94d4bc2b2eef8b44ab6336.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4d04cce29e9f55c4b065978ee3659f6',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/c76a8a9d0fee0cc2fc5366c04407ed11.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7861e5995911305a70cbd6d056439711',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/a9d026e98d49884a06fafa4dc368d988.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69594491e55dd2c6038512c490e94c76',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/416bccdc03583ba908109b78ecd818a4.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f61e37c4dba85efa9013905092d42be2',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/6e488a8ebcdecc01cf9a778635114c15.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '021d84ccff43d222968eac0591648e15',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/086ae3e51797d00068d32c7973b2aa55.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0f781ad90ecd5c02bd1b4974ac13165',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/bfa0afcd883e62215351a6cdefe33a7a.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f114305f738c68b00698760355b6e3b8',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/66ddfb3887fb4d07a726a955e76c1277.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '322409b7e75270c154c1358b008baaa3',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/af50a32801dad2659957e98b1a3addc5.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1076c1240e14839cb7fcc63c2b1f7d97',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/689875b153071a646ddd9b239df5484e.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e5d6aab81091efc7f48cc04cb9f051b',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/88e5c2ffd3162eb3f5b1ab5b9719b9b0.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'decf30a695553a9f90cde7784d4ed49a',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/2c16c53cb0dc32c9aa27aae4a56ee90c.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8cc1c8b207a9f1fec4de7cfb9398faf3',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/730c689e04dde38cb239de160a5af725.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33a2911c72ae14bc5b8b781bfc028b9b',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/5e1ee3bc5a96bd64b2147da91f0a0132.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48db700fe479e1bbcd8649ced49fc26c',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/5f7a636192770a062fb4450da80df66d.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3dd38b40b8e6aca0ab60366dc13c32a',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/e1ffdff2e92cb92a9460c306cce4eb03.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5509c6f804b4d53af72ffd743d45900c',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/aa8bd75beb9bd6927cdd631b7383692e.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2a94685d6e9b724dfffade83cd67bac',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/ee9718d763e02a63b8645e184d23aa61.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '913b253f6c45cd3f7627d0f56591e678',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/92851c3cff0d002ed312543a1499bd88.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '868fa689c48e715862d35a487bb4d6a1',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/053731bdfe40402f2e6c2573d6f0c84a.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdb02716590e90a503d88ead8cc7d4c3',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/9fc7b38dace1120c84475dc49838bba3.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4dc57a4ac71743bd4e216274ce3e94a9',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/2b235733a1ce0a20c6b1ce89d1096163.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '342a22e3e1a85aa903da5d98e2b7b548',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/69b45e17b3b1c62c6b8ee8786b9b5c9a.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6bb557ac15ea4effcd44ab988695df1',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/1a843d885681d13d9a3365ee9d14c47a.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2d025a3004facbc4816f08146270905',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/98bbd34430775355cdea91a0a56a8730.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9a5152249a7afd993dd152d6dfc462b',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/cd247c7b646a01935c8f49c3fbe5323e.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18463f782edf45d9e919f608e070b8fe',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/f2f16d07b59a2d9f6ab9e9d971029c94.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb484b804ae3c9aa5997760ab7f9b703',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/c97e5673d96d91260efde9ec9177cab8.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b611bbb67d48bdb0213e03450576382b',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/798c38bdef191cdf5a18e0a2c657092c.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84eea14944c92b0d3a2469d10ae55757',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/64eb1479d70a1e3f7b86582b00063ad3.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56599a258ffc5f8cd139d064d11a4588',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/71d987a5bf0cc4eb649cedb9fa7c20a7.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd595ef35771d39a93b43066584e561cb',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/f7368993f3dbc8f22ea1564bb004d98f.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2baa96d6d8548a79aa512fbc4dda646f',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/d1e5439e0f43e3123a24e86d52d3d419.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46402c69095d0acbf9e93eda1f975fee',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/414754ccc9b3015b418474a3e91370d6.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ef58657e7ffc94efbcdf5780091ccff',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/23374662eb608893f230939b0c8efbb3.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8719c90fb8dacb53896093028b94b0a7',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/8ca184d0bb6187a0a7db7a00ac15194d.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2183944b7d050b94a78e1162d205b48',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/44c239ee3220fc68d8c187fe2547f760.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '668e12e93fac8000d4152fac7276dfaa',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/0057e6049581c6fef848ef33911c448b.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08838f2dc6f7e141411575377a415ca5',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/49668059a94d84e5548351a88bf150f1.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4208f5bb36852591e3b8aee35df4df48',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/2181282352df34dbb164aaeba823637e.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e65c9e43495c1911a1615006ca66676',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/2568749320266393e8a394b01db12348.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4a8af7bb9ab958093d216d31937b1e4',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/4470e554667721c0920cbf42ba00930c.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5680970a4287823e6077618e4fc63a6d',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/997705bf63b6d69bf1d6991d92d3ab11.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e628172e7483e7f996cf36f34313ff5',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/20c8402140aee57e469216d9cff0f703.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '266d2a8271f216831a51763d026aea82',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/406c1481a2724c29d342d7551ca46f07.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '712650973dc5a185315c1abec152a907',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/bdb05daf571cedda41190b8458737cfe.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e25efb57e305b456e5f456672763083e',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/0b42cc17856f8c249dbf9e00189847c4.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b818251a041050116770024314a9d0d',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/2afe21d91e3f7a04b04016fc02e98b75.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7836cde1cc7c2cc1b53c07cdca15983',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/002ebb436103074bf0c06bf356e7ff8c.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '147b9b276a448701a294d1b22d94f8ba',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/5fe686d4f338a2bd9974b664420c2a98.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1783313a48948fb2cb744115e20bd1c4',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/9127167365cce2ada7592c323d919b08.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05a5b24d2a9b641382c1dbc03198e89a',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/d05f1c458562c37d9b9e473ac25d0cdc.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94daea4ce2996a5494736dec86a95886',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/95d2f1b988bb87aed1c07db1a67e4396.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '668ca2ec965e7ec7c9040c574a247f28',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/b533996f76de8347ab2192a02820e28b.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3af7fd68d1021454cb7e7d859a01f4c',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/2b7eb1c70ec761668cf15c0d8e27720e.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f45f57e79d805a8e9949cf22cb6baac4',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/5509dc1fabc34a7727ed2afa1efc3ea3.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '631108fa4f645a1ae906150cfb251aef',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/bc86387955ec6af546eab8e3615154a1.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e95b323b90957a6da5c80207160f974e',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/c4aafa3528a75ed4ace007b80719e902.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d6e7ec31592fdb66837aecbdbea5397',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/b94b766a18ca0314f8b22e944a3c0159.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5639164b24562b60a5fe30611da03912',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/8b1ea6026aca19cfaa86e873d4173b09.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8aebe71bc6bc3c40eea42e987487fe7c',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/b67f16c3a01ef0a78a9a29ac4eb7ad6e.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf72ae29caa901d6fb5e4a490040d526',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/20c1c276757786bc8f938bb4a4e1b356.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9ae679fa955f2045ae18deac394ec7c',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/290f9c935c1e73dd31f0bf84609d0554.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e70c9771adaafe69f4d2744d3ae5e00',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/782dd0d553d86b7f492ac22cd0ba033d.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e447a0e23412608e7ca2245870476f7',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/1db04668c776e7d2cefb2066b41fecc7.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef01d7045add2b7190e2271cef05af90',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/426272477b8a1288f4328c583f1b7c2c.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46531dce87f58d4ec0f0d9d9ede129ac',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/97e06096b2cd9efc3933c92c1b22a921.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e639270ab427ec70746c2b8d93cf2a82',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/0c039737f3e9616aed62336576e76c5f.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0b42d64b5325afb9962b67757c068cd',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/fbe6eb96cf3a947c9f74577fbc1486e5.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bee52981fe92925043fd5657df47ae26',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/91aa92b90b43978eaaca98c95ed1b4ad.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d1f6e01a7ee3a0da5fa96646661a74f',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/7a999f9b3f8e3834cf66409ed92dd907.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dacde3e9bba311f79f4d5fd5f44a921',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/3ecbd3d28edf2f05241beb14fcfb0825.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0958bbe8bb72eba2f8402cdb7a46622',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/fcba8e1490bea50bd1b1bf1fd8a8c5d4.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4a18cd69d72b67fae1f149c26d0829f',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/c73cb00ba33c217daea8955d2bdb40ff.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a238ee054d02a85be718d8d6ad40b48',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/ad40ca8ba110655a520e45187d3b4d44.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8123430a340d73b0518e26ef5be3574f',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/fbe85217a404d459723067b1b6d639c8.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ed5ef701030be7764f6847d3f7ad187',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/0e7cce201c1d8d49389e37f3e8eb2252.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e157c28aa9f1414afdb4c8c689d113c',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/4d0e017a224791fc7e5921027e67f90f.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3f58bb21555ead59ba5d06dd3b56791',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/14e3dd7bc2d9ccb78beaa68b47d0ba64.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4300b02a61b933c6a212afa8678a979',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/6d8f180aca1778192dc05d75db03d1b6.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c632aa835d329c95e453406924f03d70',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/798ffac94f8102fd6d7bce52cc39801b.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14fa6b0828af7521c5e1b4da7f3f3364',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/ee02eb3fd6a96af47281044afeebd065.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b3e73181e8b14f8417eb2804f0ecdbd',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/e40cb61864ceadc5b4f847ff0209c5ad.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ed4afc3a7c22907b360174877feb37e',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/27096fd00f08537ba2877a3ac018820c.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc18d0849d85afa6165ed27ba002a1ee',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/c9e9f75c335208478b1747b582cda656.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '351ee484722115d0b4e4d7aaba0c9571',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/6182c8f4c840d0125b77e6b349f44a6e.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f03bedef31a58b9a5b8421fcb8c63ad4',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/0aea542a311e0a45ad2c0fa1a6106ed1.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7e980cc1ad58b1a01661bcc66804305',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/7e9e731c7b7e0eab0093ad6bf00caf68.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd23115402dd10cd8cfee0a5062571fa7',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/927eb9dd1b801ed01d9e615ac63ddc50.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa89fb196e51294502708d465c9d508c',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/795c214d395d1296443dd73b94f61e57.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e947dd60f65a15522a9ca552effeb5b',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/dcf64388e9b3548c25db6a24cdd95174.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b4dda8801aabd0dd03beaa9a4495ce3',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/11a6322b53e03dd30181fdaf0d0d8b16.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69ebb576bfaa8a40074f6fcebf4d351b',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/7cf964fab42e1ac22e50919a3d1ecacd.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eb3698d768dbedf2337f6e2822fb69c',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/9977c5dda455da14116ca51c3a0c6e93.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc23ef623e5e29f70646ded9bb25311d',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/a1ee6f6f6ba0f10c5a840a9f611d676d.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e4104819fe514be30e2143203fc4fbb',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/f6c3d99189b92878b98bc1d5670ebcd6.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd60c04afcbb447e51a8d4edb2510019c',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/e37d62e79f42ed388c2a2a3cde3eafd9.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f58c81d25f9ab4adabaea9853209932',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/84caa9edfa00c617d6910bdd528575fc.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '758146d8c6041496d64f1afc18718205',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/7d48e586e1e98ba502950481b3d7bf23.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '059a2d2ac80149d15e91a40e44469f39',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/11d8353712e882bc2c3b86796cfd3fc9.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b59f22dbaad96c7f86ecf165295030b',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/24e9b99a36ba4d267a9ae32cb2d95cfa.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b5a8bbaca63239d96304f40ab5b7f61',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/67961a53d111ec2637a3f1f41ceaf024.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c29b6eba90ba6e12d6e025ad738f841b',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/fdbacf98c69fa2388322efeb0ca05fe2.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15673bafe79277cd24f1703de57c0340',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/a686d2b51f444f378aea4d3a0a17146c.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd792655b3892419900c1773169a65f1',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/4a8156020619880396b7bb339057ffa4.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1a306ee4435c3ad4b3c309157130f82',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/4d6f74cf146c47acaa0c5a7cfe192d9d.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca22019f43539a4664f4af7ad7f2d81b',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/703f8d49d743a37ceebc7c2c0194b167.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42cb15a3fea47f2643e1e8c5b55feeae',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/118d8c5fafdbc98f49b23c883a625a5e.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c530258a649871ccd989e99a05efd7ad',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/94febb8dbd7d3b0d28d95b38ecaf82e0.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98611668154d9c6725a92c3eb6b4b21d',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/821a3b4e58945daa30e3a6cf2a8f9a18.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b310158d7b62cca08f17853f371f41a',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/eddd9f2e93e1ae624cbbcbf50041ec12.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e336a9e6880178d6039eafab00b80031',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/eb380ba75fbab456a3f576494fe5d1c4.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9624f0637ccc8d7133cecd1344aaf6a',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/10435fa0278b05ae0c34db37276f4f76.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aaaf6d1e88637114a30f5a7ac20b3ce2',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/a5cfc514d606c99ec37867385aca703c.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f88cc9b73a068721f939a7b534cd03f',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/de234e71aea20678292353963d769697.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '157beec80784f6089fccce67e9cbee7b',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/75a86d7458c9b81720d02c93918b1c2d.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51d60f06fdeb61a1b81b7a431dcefc31',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/a1d3b37662770ab4a3119c61cccf8261.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01df969a6cd958410f00a9d3d8a1729c',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/0ef0b19ed526801a5bdfdfb99875e818.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac4d45514c78d6d76da001fee6bf9a62',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/f509a29e6509912246463e091ee1bb29.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9504e09dfa538e4b2930c46b399bff6',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/ba2ef939695e6c622079422a2352b28f.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05c5b10c7ab90dc83a3dc6d7ce2a3f18',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/9cab330fd3076dc456a2314ff02d4f4d.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b806793aa9fd8b2d200364b6838e21d4',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/0e0c71b592bb1b6c969b890c14aeb682.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81d0106b3d6b95fe873933edb7926c6a',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/abbcb15d6b111c95c0394bd754f0bd81.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a15102a3623a6b9aa9851502309cdfd',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/364df32d2198fa456a2177f35a1e8fdb.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6ac0a2917510f97fc08d23432e2265c',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/f25a741147db6f761b15f16e611ef173.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47687b41ef4c70d93d7ceb7a0e5596f5',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/fe75ffe3bd82cb53d4da7a125520f25e.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3345cb6b48abc140ad41d24b5ed02fc',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/3e4db05aaed63f9234798648502792c4.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48f7040b8a28632ec21c2138d1bd98e0',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/9f155a2ef58bde1e408cdccbd9ef368e.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e623ac8eaa04e49f612131f3620ba7e',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/fdfebac6ce1f0870c9a04d45b9ab11ae.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be4603055ca2973741e23a6ec24dc43e',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/0111075f73fe00b5c2da8861871ff2e9.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56481706eeac6d8d34cb5b6510d6268d',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/496ca6bdf1244f2c28e3162664831ff1.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e96d955c1495e9a72c758763d5c8f17',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/a1411dae625db78436b7bb899daab17b.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22eee43b16a7682c9ec335c9d3d95b2e',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/79e3325a1936befb15dedb505aeca451.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfc005096241944ab5ae095a0964697c',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/4f740767127f59656ad62564ba1feba4.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e763fe19b5455f85e23652b16c368bb',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/414d6091c21b308ed98a4f5dc99bffb7.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04809cd93e9cc64fd917ee798a449340',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/739988330582999f805faab8e9276252.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b89189f5be63e4fa4bbac66dcf0f8e6',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/4a6204365018cdc0410d4b711aaf1943.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3e67162c0888260ecdce879c63f4dd1',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/604345873b06b47aa4df8d997cecb3d1.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b99f46f0d76873489451762aa0ad62c',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/9a3c4d33e5696321385d2a0fd57c8d73.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a6ab638c045b111564094062a3dc61a',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/cf3d04e44b555ba207dbee32c6c2690c.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c8676fe9f2bafad1ce82ef4e990bcc5',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/0b3bb1243b00c9faa515918d57f1155c.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee6b899096cebe3dc20cf883a7a1e9d8',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/315dc327d742b3dc29c5dad8bee96d63.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43f4cee7042395ea5879058553dee990',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/d6a654ea79d5b6cd842847ca90ec5268.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a80f419b2de7dd2a7e8c53a9f4876f9',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/def8b02da46a7a45e900e7b64c437fd2.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c2e989fd6b967d03380cd7b2da67220',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/2ce39210dafa8b675f9b897e7f473db9.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef978a4e9d1ccd98ed814afbdbcd9965',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/fa12c672366ed7dae4b3c72841427f9a.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a92eb978fa50aacf54b51444e166a1e1',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/9f29f66b16b73f8c733d03d536d483c1.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c01e635829a556d1146e45ff3f7983a9',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/55130491ad0c519ed20c138ac3b73c62.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70802b636130e85f33a28138572cc026',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/a7c34c3f63ca7bd04c3996c04d7464e6.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e462a06b3acd649fe4b6556dc997d4d',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/d4671ca500713381c247fecdcc2d6495.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdaa0f5d25f7f089312a60ad017c01d0',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/8dea4a1add9a3907179d92977e045441.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '760346541fd8928adf7df98e1ccae6b5',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/176123751507ecde0bfbd44604f22449.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2afdd2f671ac469b9b061ca3295e3301',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/0923d936e7a47edcbf3859c731a62c17.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbd74182b78116fe99844728ba5f06b0',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/783c592646b2267c10075307dd3d9bcd.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ee49479d661e293c8954072cabf7bc9',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/c50adc092f94e3592d8497dbd51b8ae1.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '911ff372fa492bdca9fb926f2ab7b719',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/aa12d106ea6f222dbc58612c3ab22ac5.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '270a2f18a21387d568c1584edf54d7fc',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/8f75fecff48ae810315a9e67e806eda8.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '426a5a90035bbe9c1d1774f46c9db7c6',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/2907c10899d098d65acecb06c819db8b.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91ad68401ebe51d9ea08a7c962c591b7',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/b26780b1069c8b88c7e364d553977f0a.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bf4904695c1f8f838ad905148169b8e',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/174195bc15b7939ff8cd379c08d63cb6.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db711e91a0f682ffd3477bd358bca1b2',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/a4ed576bd9595af81071c26cecb887b6.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b0cac164ad6458e307aa75dd7f9167f',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/f241f6a0ca039f107d41802dc8c1013a.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '286ccc9e4862736287785daf10835847',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/cd750dc5e5a6cc28609f03ded94c52ea.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9952b3e16428874b6b5bdaff120e2015',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/d356634fa0a96446efc72a333b42eb13.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9652fe8306e1b01cffdfd972a4d770d1',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/84065e6ee585fcd1aedc2fe9d9bd1202.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a1b93dee3fde24e85a670752a01f8e4',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/d07868345bb260dfdedf41d5f76e3eac.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bf81270750b10408d7bd0a320a168ec',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/8795ef68747b06cd1860d5f8638f3109.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1164a913996c88c42fd6ff452d2ec251',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/f2e8dd0542823f3cf5f898e35274b396.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92d2b8601ab0df471508ef683b107e30',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/a576a3cbdc5626438f5ab44550f6e277.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aa59f0621abef0a40b035b43b921ac1',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/36900dbf5a8639bdd4777c75b3f4f81d.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0743fa7dc4eac46e48789314169f26de',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/ef60bdf4b635978033199aea15d5638a.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80c4ef5f0d56506c7f1488cabdb7bca4',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/d0ddc5b5501cdcb28ca53620dc0d6dc3.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '750d41d3511cced5e9dc1af805033aa7',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/79a24e706dce6cba868a82600f0f8e66.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d1ea9b4ddd1293f28ee35928bd4de1e',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/5e75a56f9d5b87fb398d0b7e1790e261.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ed50b57fe6ee30b717276abe7016c0f',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/745ef2af47431a1aadabe83af641b414.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '776cb80328262ebafeae2656b8ec70f2',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/86b819916be42cf9e2b2ed4290335d39.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5cc839f0dc5f54c0eac759a2a23e993',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/9b330075e180688d0eb714a07dc3de9a.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10e4b50c1ade91051d480563f2971f85',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/ad9e795506955e7c54813780e8e75acd.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6b15ab1419dbf3d4fe5c951b108abd3',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/81a788e942089edc6dfbcb61c3f6ca37.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54367f8f2aff299a0e32e4687aa83999',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/d11e52da0bd222e27355da17e1d5a7e9.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59750c79b169f43c760b3c4e04d8035c',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/f150fdc586c878b90cb1672259ac1f14.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '371980dd925f8ea24520273ae6de037d',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/58f47e41ec0b5c1329e48445f23a7e19.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44aee8cf42f4680f7d8bfc669dd34066',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/e9cc76c77558e19c8fbcc8a71c74831a.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55d4fe87134495313ff0671228226b8b',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/aadf93a7c853f4d4916da5b0b83ca28d.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10379362a5ceaab3edd4ffcc29bb373f',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/6472e52254affffd550251f459d88e89.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a73e4d0ba7837ec7eef6fdd0d4d0f729',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/7b262db8af515118c2d938f3fbf2e475.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7a82661e75c9e6b5d84337234ef656e',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/5ee2be5218522a5d7dcbed239e2991e0.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fe17014ab5b0868bd6702a56611e04f',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/5c070b764de11a9ddebda329beaaba51.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a0a5285f248ab187d810eb0206967cb',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/944b3bd070ea611ae98089099a749e5b.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14c2cd442d5a6aa0e3054dba52555490',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/8ad1bad3010461ee7b3dd4f89d2b2346.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c8096b8585ace6ecb770472f4cfcda0',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/2914e4a8cc1ff358866df352b568efe7.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd07784820fab3bcedacb0551913caf1',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/b91212e57caaa98aeac4bf3508a3a6ca.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55b49c0f75b33cafc0f5fad9aa696b53',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/cd977790c3b01cf353900636f2220d9c.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a61b36fa3ea5d4ba00585d0a35a33717',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/ea4b022f14049ddb91a3756d9ff3f95a.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aaaafe3f9607fb7c5f561ddc2188e1b0',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/7bc3156326a882c3dc7aa048f257878d.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cace359a3f57bf5db13b57df5e561b8',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/5bb6960ea1f2362a1e30c824ac49fd7c.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37319bc4be11200da9edb432d1086049',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/4efa548b0b24555ac6610a015423cb4f.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4943d2fb03e89aebd5d4e83f37080497',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/e66d19b74680db4cc094ee4a92a992b7.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d8f1bd15c732b8bcea6ddc7e0def7e9',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/3f6f0b38370dbd1838b193f2217be5f7.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7261b84d624f52b3176ad6660ebb2d14',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/14ac05f77cd5c9d95f4d9b8d1e0e181f.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '716be929ed669fe3351bffb394e1fcae',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/be1e5d959433c391407a43e775b4f44f.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33055efd592bd017aea376047c0f49c2',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/5be2649c133971f3e3cc9e58dab4d378.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea9dfc4e6317233d7d9f46785d987d52',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/3cb7bcad4da2c77ae40be1a5fed73be9.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50ecfed0cf1b82a31d6347811a09357a',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/67ebeee5b6fbf2b39e92935fd75d2cca.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d26409bf38703884ea66d1c61cf7b38',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/b6903ca006d5530ca71fde26c46a8a32.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2756c04ea7fdfa97eed17344d417d8ed',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/054a5ef23b582db9522f197dd4e57726.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c29b8d29c3dfe40534c380bcbc25897',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/8036bc259fa35b317f536ff61b9e56d5.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bc433bef9478713e0096276ab77a9a6',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/09c5ae93a55cb8c35c5e97caafec857c.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c75cbe483ec3c7e83491a554a30b9900',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/ec35044749ea6a1782c5b076627ccc7b.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fdd62e28e5133626c8eeae8449e60e6',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/bc60aba47bcba0a87f91e08259c52209.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d93dbce1fb8851ba5eec64b333d83da',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/4ea9aff421c37d4f13584a99ac5cc8f2.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08b4b47ec200e8754d32a6a1d9a4940e',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/87c21b173ace7a4b6bf9823f6c5d6d08.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be84a82a179b12c64042bb963bb72568',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/759c1ebb99d5908e98e661a6e61230bb.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af1e57108242458488345bb4deb77a38',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/99d14a327b46ce5a796d7294129f805b.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb6797c8d94af09985c6379ce18c0c35',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/8c2e90b62e7db9ce991ee1699f4243cf.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0feef8022cb9b5158668b4550d8f5702',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/1debeba56b35575dcb2f0a86577cdeaf.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62dc857abb457db41473ac57fe643e2a',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/c760cd93b462b3d222c5c3a36c4cee4f.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20965bb2a7b68520dfe50db8796b7430',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/af604b59d53ac52422be516d8307b63f.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '657aa09c1450e7ffb89fa2f2f7f755ec',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/158bfed38f1ae3dc2ba157706a51dca0.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a616d51612d7ecf500497c5ad203ef7',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/3bd867cd91577adf85f30e76093a482a.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e399d9d693bd0c3f51504b08b075aa1e',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/c73d55a9aafc10259c7cf9f270577702.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '927a39fee90ff006b8324a3c1b69df0d',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/9dfd7b846a62600e600c29b0dfb0f907.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bbf12772b26ed4777dbaf6ae29de9aa',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/a9359ffea5efc9e510b1767bd1a570c2.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b20703b8ae75aabab12ac58b7754228',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/4e30fdf26e8464ef634787312e330640.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '017d61c9b1624762566f1cdd3b4c7ced',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/30705ba8af28f065920f207e06f7a97d.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '476fe317a846fc84dca1abfb5ac12dda',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/6ca35dd5f806d095765cc338bd98ae1f.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a786d869b59f01d128827c3a336f71d4',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/2941c165b50aa7b49475dcfc874bfde6.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d250c7b4d7759e68315487fcd6113ac',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/4b7851d0666c5669931e0dc7785a234c.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2b287faa2d15696ce8c0701ae21f7b2',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/c74c7f6c329dae25fd1924489b392699.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '213da107294b94966ecab4e4558c42b4',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/d9a513d08a72fdf6cf883082c8e33cdb.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e73188c09e630209eebe9694a82fa6c5',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/14231e518615eb232142d0ad26bff79c.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1dca2725bf02a00a38c529ff73b2918',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/b86ba9c14e3f937a1f541237ed534824.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e7c4e5980a46c716d8e3695330e78e0',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/dfcdedb5d99316907c3f43d64081adae.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e82130f97999b27f5f4f4a2fd09c397',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/d35aa45eac05dff4a1e0efefeb5b26e5.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9afccbd4808b9053f83f57ac62880d4',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/62bf0c44330349fdb556afcc807c3c55.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2d05eef715b4ba7395de0df0fd90727',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/6f25105907656ac30ffb45fe7dbad92d.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2652bee117952b954786bd6d96a08b6',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/67af26ea71f4490be8f04c6523f2f45d.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a4c12857a3d3538734f636068988e04',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/c5f731c71e2e11a41d54cd4d05a8488a.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '878e314f6c563453eeaafa0f0a11fdc7',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/a5c97414ab691a154b143be34cf787cd.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b35d83ea69099b2d2391f20bf82bbafc',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/9df58da562102bed46660fa84115a99d.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27983014b235da8110b8c14b5e598fa0',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/322f8dc08c8c1d40d8bc957b17369607.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c5bb0eb15a2d52f950b8bc0dd53f8ba',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/254234ca0a714f9d65524ed0774b02a8.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1babf79530653399c29b9b484ba2bdd',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/bcc584cd68424ce79b3ce38a811e1527.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9384787249cf30a7c61d3d03fd395217',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/be4761c1bfee9a098ae1c1912d11ddba.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8ce91ea2d54a2a213e18b2cea4f3548',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/9f582be2e700f48a31a07ca4348fe0a1.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb5e6335a77d77fface69a2486972d07',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/e36b08f1d6a474cbba320ff115887849.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fa7a45f54256fb701415dcbc3b8c946',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/0376eb19d7671333bd54a05fa492020a.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad0dc66b8db7a01153af5be4bab9c12c',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/12b0a3fd6a8456d93a8b7ef6252f7c4e.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bd9613b61578cfb9f1e7eed078d2a86',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/314d523988a068caf36540d9e4bec9c3.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7a3d9d2c542cf238db3f341b1d035dd',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/ae554e9534cdefd4ee8b0c8a77325ed1.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a46e5f5afe3c2021a329782d67ea2f7b',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/8821b23cd5dedb5ce48c96366d114e2b.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e38a68a06c418842d7e3d656358df0e',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/e6200c9c5c7c9913465eec9babbeb321.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae0a831e47f3b25cc828e97a1f01627e',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/6823040a40108142e6e2cfbbcc81d056.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0794b35233315d1332471d367b2ec9a',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/eb3bdffbf35fd06648c999a3f4479326.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff878e45e956c85d60586cccbda95868',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/1ee14ab7dc19b95c55c530f00d1ab829.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ee9da66cd2b590168f2c44459600627',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/21a2706778f01556fe3cc60cbab2b69f.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41106b15bbfcd06ad673dfcc61e41c09',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/b9140be5ca0dd4172943152a2302452d.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0546dc2d1453090642d2a0575112fe26',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/17e394bead8df9dcaa4e7c412c53a76b.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1ccac21e087ecf505cdb9721799bb7f',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/a088a29cd1e51905f5b66c3bd9411bcb.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29e2ff339162a215a6803f98ab09b3eb',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/854bc00c022f41c35aa444d1399e3c75.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7340b2f7669b8f266ab765c7a2f3bda6',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/08309990a18166d2003f082225c13fe8.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '806202dbfda541e2b4fb48858ab97b2a',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/ac57b42429458e2f6fffb2d15f805f39.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '54de52d1dcc67ddbd15e1638695d5eac',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/44b73fb1789535705fc768d2bf82a2cd.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'f516d83e9e2f017c5a8c0e10ea2b0063',
      'native_key' => 1,
      'filename' => 'modUserGroup/ff9188e89304dbe33f7148e1b8c915ff.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '4ee897439db36eadc49b4f4ff837c09d',
      'native_key' => 1,
      'filename' => 'modDashboard/7e0906256e697d3fc540f574c3547a47.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'd4706bcfc966fbcd0611f7b91ac253b3',
      'native_key' => 1,
      'filename' => 'modMediaSource/f4655951fb5b98248955589dc15abd4c.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a8efc9262d4c7806caf0a3d6550276b3',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e7688a47e53004a8279ef8c6d4fe3d95.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'da62c5a1351bfba6015abc3a0a717e75',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/83df285e9990e0c2721c0fe968534c7c.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '54672e69dde6578be4010a60bb56c749',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/8c8330036859a6b54e7797006afd82a2.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '151cff67485d66e36fcf3a902b030cc3',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a669294f10e569c21e75e00bf0fde456.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd2dccdeb69beaa4ababf5edcc759ccbc',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4757192a4d5d5e8447adc26412be27a1.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '8d27d66c01ffa48f3ec78a6ab0baf445',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/aa9c91f278942d943126143878e27c36.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '3b4cf2c50e5b0a88d7cc72807b176bd7',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/c43cced1222127eeab85ec08e4f341d2.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '05f34e9638a0772183c09ec1ced6bd70',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/709eacd9cd4c4feeea89e5066ddb3840.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'fe380b7558db0aa192ca59582b70c973',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5ee9230f92314087a137fa69fdd26cc4.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '6db846a51c97894695f12638a8f13640',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/83fadd3dc9821b895444bd0fdb30e0de.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '8dd8525390efc9d93c48f6612c572eca',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/49f204c0909be4d8e33a75f03ad8fd27.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'da47d6846375253fa6e76c286cdd5e45',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/36cb810cecb0a0c5eec421c82b797e73.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '0b315aa0c80309a456ba456c77acc735',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a982654bf32b7c75f172105dd29d13eb.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '89c3c731209456dc8903b88ccece7f47',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/47c3dc275162e56717271af2881f9cdd.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b8392962c46e7b946215c7376271ff98',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/52be9ea132d848fbc0e2057260a853f7.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e54fc457166f081b796cabd02bece21f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/598ba4a3f16b616dce3f0cc4b2c127b4.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3400d4820b168a92af8d3c28bacc7693',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f660ff88078f0b4504c9a00d70e5c478.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5e17ac1c22dcc4c7a3869a794d548b7a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3d600fac3bc5ec04e5fee14fe4877447.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bcfc0aefb5ae4c2702c4556770f52fa8',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/553fd86434853470f160791bb6a5dbd7.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f1cf0dd7346ad808091d546798ee4129',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/85e5b4b5e54bb4ac833826c946835722.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cea382d8552c64c665d6b0380502322a',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/ebe526275c3d24426cbbcf2ce31dd55f.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '842d7f16a0ded566f1189096ffebe254',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/61436f0707a1221e06177aa797e5399b.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7eea8d534a704c8357a8dbfd67f32554',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/cd1dc7077ea01f58e5ed5b0aa255ae44.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c7f0b7540d4944ad71c3800bd517c6fb',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/388b05ce46a0e1334e917333f98145eb.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'dbbe422f2c055de0a7f52c3cb08476af',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/47b6e1084521981ec1b78a57ea73166a.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'bbefe4ed36eaf84066c1366736954b35',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/2c26d12cbc8f2501ed6f2e4b57c5753f.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8a7e6937853008fc9d22ccedcf3fdefc',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/50826f01cbc5df384f1224ed5ae766d3.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0dbdb5f048de45dbe1254721181b1770',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/a5d890508a85aae3540184c6c4ecdf2a.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '584c1efcf13b679b6626a31e0a282ed5',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/c5c1d100dce04abc5b25eaefc9944b65.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '5ad53d9c7c31bd7a37463c46f03b908d',
      'native_key' => 'web',
      'filename' => 'modContext/fbe588bf94ac0fc526191f9078ef2f8d.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '58cac47cb04e493a155d43966bcacf96',
      'native_key' => 'mgr',
      'filename' => 'modContext/f6224008998d7fcdd71e0d0661c42173.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd854ba6b90806c705b0e98bce0b19919',
      'native_key' => 'd854ba6b90806c705b0e98bce0b19919',
      'filename' => 'xPDOFileVehicle/028b300e1dacd334f1b4ce7c2299d8ea.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9c6762025b1422fba0246a22a38ef4dc',
      'native_key' => '9c6762025b1422fba0246a22a38ef4dc',
      'filename' => 'xPDOFileVehicle/9868814938fb1d0ffb4120f7b6e844d9.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c565e46128ef8c4d0322848a34c04284',
      'native_key' => 'c565e46128ef8c4d0322848a34c04284',
      'filename' => 'xPDOFileVehicle/d47d1367e4be3bb90011ffb18e387694.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7e685194980b2d1c45a159941d8ddf51',
      'native_key' => '7e685194980b2d1c45a159941d8ddf51',
      'filename' => 'xPDOFileVehicle/9a4d8c980564fa2e00b99f3499759868.vehicle',
    ),
  ),
);