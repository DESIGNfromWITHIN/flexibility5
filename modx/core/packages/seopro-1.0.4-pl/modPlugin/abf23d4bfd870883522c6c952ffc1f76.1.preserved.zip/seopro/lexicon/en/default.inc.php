<?php
$_lang['seopro.keywords'] = 'Keywords';
$_lang['seopro.characters'] = 'Characters';
$_lang['seopro.characters.allowed'] = 'Allowed Characters';
$_lang['seopro.tips'] = 'SEO-PRO Tips!';
$_lang['seopro.focuskeywords'] = 'Focus keywords';
$_lang['seopro.focuskeywords_desc'] = 'Fill in your keywords separated by a comma (example: table,chair)';
$_lang['seopro.prevbox'] = 'What does it look like in Google?';
$_lang['seopro.emptymetadescription']='<i>Fill in a description before an preview can be set</i>';

$_lang['setting_seopro.delimiter'] = 'Delimiter in Google preview.';
$_lang['setting_seopro.delimiter_desc'] = 'Delimiter between Title and Sitename';
$_lang['setting_seopro.fields'] = 'Fields where SEO Pro will work on';
$_lang['setting_seopro.fields_desc'] = 'Only change these if you what you are doing. Default value:pagetitle,longtitle,description,alias,menutitle. Will not work on the content field';
$_lang['setting_seopro.version'] ='Versionnumber';
$_lang['setting_seopro.version_desc']= 'Current '.$_lang['setting_seopro.version'];
$_lang['setting_seopro.allowbranding'] =' Allow Sterc branding in head.';
$_lang['setting_seopro.allowbranding_desc']= 'Give us some love...';
$_lang['setting_seopro.usesitename'] ='Show sitename in the Google Preview and place in the sitename [[+seoPro.title]]?';
$_lang['setting_seopro.usesitename_desc']= 'If the value is NO the delimiter and sitename setting will be removed from the preview en seo title placeholder';