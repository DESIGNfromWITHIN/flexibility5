Flexibility 5

Author: Menno Pietersen info@mpthemes.com
Project owner: https://anyscreensize.com
Copyright: Any Screen Size - 2015

Official Documentation: http://flexibility5.mpthemes.com/docs/
Site demo: http://flexibility5.mpthemes.com/
Manager demo: http://flexibility5.mpthemes.com/manager/
Bugs and Feature Requests: https://github.com:DESIGNfromWITHIN/flexibility5