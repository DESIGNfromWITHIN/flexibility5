<?php
/**
 * Properties file for [[+element]] [[+elementType]]
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
 * @package [[+packageNameLower]]
 * @subpackage build
 */


