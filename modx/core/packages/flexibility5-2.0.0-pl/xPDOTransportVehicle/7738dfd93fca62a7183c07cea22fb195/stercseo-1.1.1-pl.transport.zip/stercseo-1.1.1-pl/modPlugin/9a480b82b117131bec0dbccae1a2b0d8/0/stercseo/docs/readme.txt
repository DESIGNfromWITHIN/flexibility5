--------------------
SEOTab
--------------------
Version: 1.1.0-pl
Author: Wieger Sloot at Sterc <wieger@sterc.nl>

License: GNU GPLv2
--------------------
