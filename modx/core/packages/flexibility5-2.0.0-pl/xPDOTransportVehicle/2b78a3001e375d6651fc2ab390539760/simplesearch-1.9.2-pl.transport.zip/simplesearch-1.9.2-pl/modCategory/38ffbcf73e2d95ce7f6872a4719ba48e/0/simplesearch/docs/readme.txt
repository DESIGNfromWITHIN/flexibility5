=====================
Snippet: SimpleSearch
=====================
Version: 1.9.2
Author: Shaun McCormick <shaun+sisea@modx.com> et all
License: GNU GPLv2 (or later at your option)

This is a simple search component. Please see the documentation at:
http://rtfm.modx.com/display/ADDON/SimpleSearch/

If you want to use the Solr driver, please refer to the docs, and make sure
you have the Solr PECL driver installed, which can be found here:
http://pecl.php.net/package/solr

You can use the sample solr schema.xml file found at:
- core/components/simplesearch/docs/solr.schema.xml
Just rename it to schema.xml and place it in the proper conf/ directory.

Thanks for using SimpleSearch!
