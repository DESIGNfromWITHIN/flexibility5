<?php

namespace Elastica\Exception;

/**
 * Client exception
 *
 * @category Xodoa
 * @package Elastica
 * @author Nicolas Ruflin <spam@ruflin.com>
 */
class ClientException extends \RuntimeException implements ExceptionInterface
{
}
